public class FullStackException extends RuntimeException {

    public FullStackException() {
    }
 
    public FullStackException(String message) {
        super(message);
    } 
    
}