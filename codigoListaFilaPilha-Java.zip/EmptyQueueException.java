
class EmptyQueueException extends RuntimeException {

    public EmptyQueueException(String message) {
        super(message);
    }
    
    public EmptyQueueException() {
    } 
    
}
