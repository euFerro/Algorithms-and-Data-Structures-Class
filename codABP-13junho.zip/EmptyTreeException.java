
public class EmptyTreeException extends RuntimeException {

    public EmptyTreeException(String message) {
        super(message);
    }
    
    public EmptyTreeException() {
    }
    
}
